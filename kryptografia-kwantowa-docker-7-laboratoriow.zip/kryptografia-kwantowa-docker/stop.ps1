docker compose down
